<?php $__env->startSection('content'); ?>

  <!--main content start-->
        
  <section id="main-content">
    <section class="wrapper">
      <!--overview start-->
      <div class="row">
        <div class="col-lg-12">
          <h3 class="page-header"><i class="fa fa-user-md"></i>Client's Profile</h3>
          <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
            <li><i class="icon_documents_alt"></i>Pages</li>
            <li><i class="fa fa-laptop"></i>Profile</li>
          </ol>
        </div>
      </div>

      <div class="row">
        <!-- profile-widget -->
        <div class="col-lg-12">
          <div class="profile-widget profile-widget-info">
            <div class="panel-body">
              <div class="col-lg-2 col-sm-2">
                <h4><?php echo e($profiles['name']); ?></h4>
                <div class="follow-ava">
                  <img src="<?php echo e(url('/Admin/img/dummy-male.jpg')); ?>" alt="">
                </div>
                <h6><?php if($profiles['role_id'] == 1): ?> Admin <?php else: ?> User <?php endif; ?></h6>
              </div>
              <div class="col-lg-4 col-sm-4 follow-info">
                <p>Hello I’m <?php echo e($profiles['name']); ?>, a leading expert in interactive and creative design.</p>
                <p>@ <?php echo e($profiles['name']); ?></p>
                <p><i class="fa fa-twitter"><?php echo e($profiles['name']); ?></i></p>
                <h6>
                                  <span><i class="icon_clock_alt"></i><?php echo e(now()); ?></span>
                                  <span><i class="icon_calendar"></i><?php echo e(now()); ?></span>
                                  <span><i class="icon_pin_alt"></i><?php echo e(strtoupper($profiles['country'])); ?></span>
                              </h6>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-comments fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-bell fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-tachometer fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <section class="panel">
            <header class="panel-heading tab-bg-info">
              <ul class="nav nav-tabs">
                <li class="active">
                  <a data-toggle="tab" href="#recent-activity">
                                        <i class="icon-home"></i>
                                        Daily Activity
                                    </a>
                </li>
                <li class="">
                  <a data-toggle="tab" href="#profile">
                                        <i class="icon-user"></i>
                                        Profile
                                    </a>
                </li>
                <li class="">
                  <a data-toggle="tab" href="#edit-profile">
                                        <i class="icon-envelope"></i>
                                        Edit Profile
                                    </a>
                </li>
              </ul>
            </header>
            <div class="panel-body">
              <div class="tab-content">
                <div id="recent-activity" class="tab-pane active">
                  <div class="profile-activity">
                      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="act-time">
                            <div class="activity-body act-in">
                            <span class="arrow"></span>
                            <div class="text">
                                <a href="#" class="activity-img"><img class="avatar" src="<?php echo e(url('/Admin/img/dummy-male.jpg')); ?>" alt=""></a>
                                <p class="attribution"><?php echo e($event->ccie->name); ?> | <?php echo e($event->racks->name); ?></p>
                                <p><?php echo e($event->start_date); ?> | <?php echo e($event->end_date); ?></p>
                            </div>
                            </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                </div>
                <!-- profile -->
                <div id="profile" class="tab-pane">
                  <section class="panel">
                    <div class="bio-graph-heading">
                      Hello I’m <?php echo e($profiles['name']); ?>.
                      
                    </div>
                    <div class="panel-body bio-graph-info">
                      <h1>Bio Graph</h1>
                      <div class="row">
                        <div class="bio-row">
                          <p><span>First Name </span>: <?php echo e($profiles['name']); ?> </p>
                        </div>
                        <div class="bio-row">
                          <p><span>Last Name </span>: <?php echo e($profiles['name']); ?></p>
                        </div>
                        <div class="bio-row">
                          <p><span>Birthday</span>: <?php echo e($profiles['dob']); ?></p>
                        </div>
                        <div class="bio-row">
                        <p><span>Mobile </span>: +91 <?php echo e($profiles['phone']); ?></p>
                        </div>
                        <div class="bio-row">
                        <p><span>City </span>: <?php echo e($profiles['city']); ?></p>
                        </div>
                        <div class="bio-row">
                          <p><span>Country </span>: <?php echo e($profiles['country']); ?></p>
                        </div>
                        
                        <div class="bio-row">
                          <p><span>Email </span>: <?php echo e($profiles['email']); ?></p>
                        </div>
                        
                      </div>
                    </div>
                  </section>
                  <section>
                    <div class="row">
                    </div>
                  </section>
                </div>
                <!-- edit-profile -->
                <div id="edit-profile" class="tab-pane">
                  <section class="panel">
                    <div class="panel-body bio-graph-info">
                      <h1> Profile Info</h1>
                      <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('update-profile')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" id="" value="<?php echo e($id); ?>">
                        <div class="form-group">
                          <label class="col-lg-2 control-label">Full Name</label>
                          <div class="col-lg-6">
                            <input type="text" name="name" class="form-control" id="f-name" placeholder=" " value="<?php echo e($profiles['name']); ?>">
                          </div>
                          <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('name')): ?> <?php echo e($errors->first('name')); ?> <?php endif; ?></span>
                        </div>
                        
                        
                        <div class="form-group">
                            <label class="col-lg-2 control-label">City</label>
                            <div class="col-lg-6">
                              <input type="text" name="city" class="form-control" id="c-name" placeholder=" " value="<?php echo e($profiles['city']); ?>">
                            </div>
                            <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('city')): ?> <?php echo e($errors->first('city')); ?> <?php endif; ?></span>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label">Country</label>
                            <div class="col-lg-6">
                              <input type="text" name="country" class="form-control" id="c-name" placeholder=" " value="<?php echo e($profiles['country']); ?>">
                            </div>
                            <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('country')): ?> <?php echo e($errors->first('country')); ?> <?php endif; ?></span>
                        </div>

                        <div class="form-group">
                          <label class="col-lg-2 control-label">Birthday</label>
                          <div class="col-lg-6">
                            <input type="date" name="dob" class="form-control" id="b-day" placeholder=" " value="<?php echo e($profiles['dob']); ?>">
                          </div>
                          <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('dob')): ?> <?php echo e($errors->first('dob')); ?> <?php endif; ?></span>
                        </div>
                        
                        <div class="form-group">
                          <label class="col-lg-2 control-label">Email</label>
                          <div class="col-lg-6">
                            <input type="text" name="email" disabled class="form-control" id="email" placeholder=" " value="<?php echo e($profiles['email']); ?>">
                          </div>
                          <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('email')): ?> <?php echo e($errors->first('email')); ?> <?php endif; ?></span>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label">Mobile</label>
                          <div class="col-lg-6">
                            <input type="text" class="form-control" id="mobile" name="phone" placeholder=" " value="<?php echo e($profiles['phone']); ?>">
                          </div>
                          <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('phone')): ?> <?php echo e($errors->first('phone')); ?> <?php endif; ?></span>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-2 control-label">CCIE Track</label>
                            <div class="col-lg-6">
                              <select class="form-control" name="ccie[]" id="">
                                  <option value=""><--- Select ---></option>
                                  
                                  <?php $__currentLoopData = $ccies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyItem => $ccie_selected_track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($ccie_selected_track->id); ?>" ><?php echo e($ccie_selected_track->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                              </select>
                            </div>
                          </div>
                        

                        <div class="form-group">
                          <div class="col-lg-offset-2 col-lg-10">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="button" class="btn btn-danger">Cancel</button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>

    </section>
  </section>






    </div>
    <div class="widget-foot">
      <!-- Footer goes here -->
    </div>
  </div>
</div>

</div>

</div>
<!-- project team & activity end -->

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminHeader.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
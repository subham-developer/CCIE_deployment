<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
<section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> Events</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
              <li><i class="icon_documents_alt"></i>Pages</li>
              <li><i class="fa fa-laptop"></i>Show Events</li>
            </ol>
          </div>
        </div>

        <div class="row">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success fade in">
                <?php echo e(session()->get('message')); ?>

                <button data-dismiss="alert" class="close close-sm" type="button">
                    X<i class="icon-remove"></i>
                </button>
            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
              <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>

        <?php if(session('success')): ?>
          <div class="alert alert-success">
              <?php echo e(session('success')); ?>

          </div> 
        <?php endif; ?>
        <div class="btn-group" style="padding-left: 20px; padding-bottom: 20px;">
            <a class="btn btn-primary" href="<?php echo e(route('calendar')); ?>"><i class="icon_plus_alt2"></i> View Calendar</a>
        </div>
            <div class="col-lg-12 col-lg-12 col-sm-12 col-xs-12">
                <table class="table table-striped table-advance table-hover">
                    <tbody>
                        <tr>
                            <th>
                                
                                User Name
                            </th>
                            <th>
                                <i class="icon_profile"></i>
                                Category Name
                            </th>
                            <th>
                                Rack Name
                            </th>
                            <th>
                                Timezone
                            </th>
                            <th>
                                Start Date
                            </th>
                            <th>
                                <i class="icon_calendar"></i>
                               End Date
                            </th>
                            
                            <?php if(Auth::user()->role_id == 1): ?>
                            <th>
                                <i class="icon_cogs"></i>
                                Action
                            </th>
                            <?php endif; ?>
                        </tr>
                        <?php $__currentLoopData = $eventsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($post->users->name); ?>

                                </td>
                                <td>
                                    <?php echo e($post->ccie->name); ?>

                                </td>
                                <td>
                                    <?php echo e($post->racks->name); ?>

                                </td>
                                <td>
                                    <?php echo e($post->timezone); ?>

                                </td>
                                <td>
                                    <?php echo e(date('d-m-Y g:i A', strtotime($post->start_date))); ?>

                                </td>
                                <td>
                                    <?php echo e(date('d-m-Y g:i A', strtotime($post->end_date))); ?>

                                </td>
                                
                                <?php if(Auth::user()->role_id == 1): ?>
                                <td>
                                    <div class="btn-group">
                                        <a class="btn btn-primary" href="<?php echo e(url('/edit/calendar')); ?>/<?php echo e($post->id); ?>">Edit Events <i class="icon_plus_alt2"></i></a>
                                        
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div>
                    
                </div>
            </div>
        </div>
</section>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminHeader.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
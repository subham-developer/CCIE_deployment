<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
<section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> Dashboard</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
              <li><i class="icon_documents_alt"></i>Pages</li>
              <li><i class="fa fa-laptop"></i>Add Category Name</li>
            </ol>
            
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            
          </div>
        </div>

        <div class="row">
          <div class="col-lg-1 col-lg-1 col-sm-12 col-xs-12"></div>
            <div class="col-lg-9 col-lg-9 col-sm-12 col-xs-12">
                <form action="<?php echo e(route('store-clients')); ?>" method="POST" class="form">
                    <?php echo e(csrf_field()); ?>

                    <br/>
                    <label for="">User Name</label>
                    <span class="required">*</span>
                    
                   
                    <input type="text" name="name" value="<?php echo e(old('name')); ?>"  <?php if($errors->has('name')): ?> <?php echo e($errors->first('name')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter User's User Name" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('name')): ?> <?php echo e($errors->first('name')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Email Id</label>
                    <span class="required">*</span>
                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" <?php if($errors->has('email')): ?> <?php echo e($errors->first('email')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter User's Email Id" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('email')): ?> <?php echo e($errors->first('email')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Date of Birth</label>
                    <span class="required">*</span>
                    <input type="date" name="dob" value="<?php echo e(old('dob')); ?>" <?php if($errors->has('dob')): ?> <?php echo e($errors->first('dob')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter Date of Birth" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('dob')): ?> <?php echo e($errors->first('dob')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">City Name</label>
                    <span class="required">*</span>
                    <input type="text" name="city" value="<?php echo e(old('city')); ?>" <?php if($errors->has('city')): ?> <?php echo e($errors->first('city')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter City Name" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('city')): ?> <?php echo e($errors->first('city')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Country Name</label>
                    <span class="required">*</span>
                    <input type="text" name="country" value="<?php echo e(old('country')); ?>" <?php if($errors->has('country')): ?> <?php echo e($errors->first('country')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter Country Name" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('country')): ?> <?php echo e($errors->first('country')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Contact Number</label>
                    <span class="required">*</span>
                    <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" <?php if($errors->has('phone')): ?> <?php echo e($errors->first('phone')); ?> style="border: 1px solid #00a0df" <?php endif; ?> placeholder="Enter Contact Number" class="form-control">
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('phone')): ?> <?php echo e($errors->first('phone')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Select CCIE Track</label>
                    <span class="required">*</span>
                    <select class="form-control js-example-basic-multiple" name="ccie[]" multiple="multiple" <?php if($errors->has('ccie')): ?> <?php echo e($errors->first('ccie')); ?> style="border: 1px solid #00a0df" <?php endif; ?> name="ccie" id="">
                        <option value=""><--- Select Your Track ---></option>
                        <?php $__currentLoopData = $ccie_track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ccie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(old('ccie') == $ccie->id): ?> Selected <?php endif; ?> value="<?php echo e($ccie->id); ?>"><?php echo e($ccie->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span style="color: #00a0df; font-size: 10px;"><?php if($errors->has('ccie')): ?> <?php echo e($errors->first('ccie')); ?> <?php endif; ?></span>
                    <br/>
                    
                    
                    
                    <input class="btn btn-success" type="submit" value="submit">
                </form>
            </div>
        </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
  $(document).ready(function() {
    $('.js-example-basic-multiple').select2();
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminHeader.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
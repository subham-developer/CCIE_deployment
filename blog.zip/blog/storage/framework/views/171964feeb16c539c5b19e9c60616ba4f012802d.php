<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">

<script src="https://cdn.ckeditor.com/4.12.1/full/ckeditor.js"></script>
<section id="main-content">
      <section class="wrapper">
        <!--overview start-->
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> Events</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
              <li><i class="icon_documents_alt"></i>Pages</li>
              <li><i class="fa fa-laptop"></i>Edit Events</li>
            </ol>
          </div>
        </div>

        <div class="row">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success fade in">
                <?php echo e(session()->get('message')); ?>

                <button data-dismiss="alert" class="close close-sm" type="button">
                    X<i class="icon-remove"></i>
                </button>
            </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
              <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>

        <?php if(session('success')): ?>
          <div class="alert alert-success">
              <?php echo e(session('success')); ?>

          </div> 
        <?php endif; ?>
        <div class="btn-group" style="padding-left: 20px; padding-bottom: 20px;">
            
        </div>
            <div class="col-lg-12 col-lg-12 col-sm-12 col-xs-12">
                <form action="<?php echo e(route('update-calendar')); ?>" method="POST" class="form">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" id="" value="<?php echo e($id); ?>">
                    <br/>
                    <label for="">Select CCIE Track</label>
                    <select class="form-control" name="ccie" id="">
                            <option name="ccie" value=""><--- Select Your Track ---></option>
                        <?php $__currentLoopData = $ccie_track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ccie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="ccie" <?php if($eventsList->ccie_id == $ccie->id): ?> selected <?php endif; ?> value="<?php echo e($ccie->id); ?>"><?php echo e($ccie->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('ccie')): ?> <?php echo e($errors->first('ccie')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Select Rack</label>
                    <select class="form-control" name="rack" id="" value="">
                            <option name="rack" value=""><--- Select Your Rack ---></option>
                        <?php $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option name="rack" <?php if($eventsList->rack_id == $rack->id): ?> selected <?php endif; ?> value="<?php echo e($rack->id); ?>"><?php echo e($rack->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('rack')): ?> <?php echo e($errors->first('rack')); ?> <?php endif; ?></span>
                    <br/>
                    <label for="">Start Date</label>
                    <input type="text" name="start_date" id='datetimepicker1' value="<?php echo e($eventsList->start_date); ?>" placeholder="Enter Start Date" class="form-control">
                    <span style="color: #d93333; font-size: 10px;"><?php if($errors->has('start_date')): ?> <?php echo e($errors->first('start_date')); ?> <?php endif; ?></span>
                    <br/>
                    
                    <input class="btn btn-success" type="submit" value="submit">
                </form>
                <div>
                </div>
            </div>
        </div>
</section>
<script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/momentjs/2.14.1/moment.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminHeader.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

  <!--main content start-->
        
  <section id="main-content">
    <section class="wrapper">
      <!--overview start-->
      <div class="row">
        <div class="col-lg-12">
          <h3 class="page-header"><i class="fa fa-user-md"></i>My Profile</h3>
          <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
            <li><i class="icon_documents_alt"></i>Pages</li>
            <li><i class="fa fa-laptop"></i>Profile</li>
          </ol>
        </div>
      </div>

      <div class="row">
        <!-- profile-widget -->
        <div class="col-lg-12">
          <div class="profile-widget profile-widget-info">
            <div class="panel-body">
              <div class="col-lg-2 col-sm-2">
                <h4><?php echo e($profiles[0]['name']); ?></h4>
                <div class="follow-ava">
                  <img src="<?php echo e(url('/Admin/img/dummy-male.jpg')); ?>" alt="">
                </div>
                <h6><?php if(Auth::user()->role_id == 1): ?> <?php echo e(Auth::user()->timezone); ?>Admin <?php else: ?> User <?php endif; ?></h6>
              </div>
              <div class="col-lg-4 col-sm-4 follow-info">
                <p>Hello I’m <?php echo e($profiles[0]['name']); ?>, a leading expert in interactive and creative design.</p>
                <p>@ <?php echo e($profiles[0]['name']); ?></p>
                <p><i class="fa fa-twitter"><?php echo e($profiles[0]['name']); ?></i></p>
                <h6>
                    
                                  <span><i class="icon_clock_alt"></i><?php echo e(now()->format('g:i A')); ?></span>
                                  <span><i class="icon_calendar"></i><?php echo e(now()->format('d/m/Y')); ?></span>
                                  <span><i class="icon_pin_alt"></i><?php echo e(strtoupper($profiles[0]['country'])); ?></span>
                              </h6>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-comments fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-bell fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
              <div class="col-lg-2 col-sm-6 follow-info weather-category">
                <ul>
                  <li class="active">

                    <i class="fa fa-tachometer fa-2x"> </i>
                    <br> 
                    
                  </li>

                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-12">
          <section class="panel">
            <header class="panel-heading tab-bg-info">
              <ul class="nav nav-tabs">
                <li class="active">
                  <a data-toggle="tab" href="#recent-activity">
                                        <i class="icon-home"></i>
                                        Daily Activity
                                    </a>
                </li>
                <li class="">
                  <a data-toggle="tab" href="#profile">
                                        <i class="icon-user"></i>
                                        Profile
                                    </a>
                </li>
                
              </ul>
            </header>
            <div class="panel-body">
              <div class="tab-content">
                <div id="recent-activity" class="tab-pane active">
                  <div class="profile-activity">
                      <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="act-time">
                            <div class="activity-body act-in">
                            <span class="arrow"></span>
                            <div class="text">
                                <a href="#" class="activity-img"><img class="avatar" src="<?php echo e(url('/Admin/img/dummy-male.jpg')); ?>" alt=""></a>
                                <p class="attribution"><?php echo e($event->ccie->name); ?> | <?php echo e($event->racks->name); ?></p>
                                <p><?php echo e(date('d-m-Y g:i A', strtotime($event->start_date))); ?> to <?php echo e(date('d-m-Y g:i A', strtotime($event->end_date))); ?></p>
                            </div>
                            </div>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                  </div>
                </div>
                <!-- profile -->
                <div id="profile" class="tab-pane">
                  <section class="panel">
                    <div class="bio-graph-heading">
                      Hello I’m <?php echo e($profiles[0]['name']); ?>.
                      
                    </div>
                    <div class="panel-body bio-graph-info">
                      <h1>Bio Graph</h1>
                      <div class="row">
                        <div class="bio-row">
                          <p><span>First Name </span>: <?php echo e($profiles[0]['name']); ?> </p>
                        </div>
                        <div class="bio-row">
                          <p><span>Last Name </span>: <?php echo e($profiles[0]['name']); ?></p>
                        </div>
                        <div class="bio-row">
                          <p><span>Birthday</span>: <?php echo e($profiles[0]['dob']); ?></p>
                        </div>
                        <div class="bio-row">
                        <p><span>Mobile </span>: +91 <?php echo e($profiles[0]['phone']); ?></p>
                        </div>
                        <div class="bio-row">
                        <p><span>City </span>: <?php echo e($profiles[0]['city']); ?></p>
                        </div>
                        <div class="bio-row">
                          <p><span>Country </span>: <?php echo e($profiles[0]['country']); ?></p>
                        </div>
                        
                        <div class="bio-row">
                          <p><span>Email </span>: <?php echo e($profiles[0]['email']); ?></p>
                        </div>
                        
                      </div>
                    </div>
                  </section>
                  <section>
                    <div class="row">
                    </div>
                  </section>
                </div>
                <!-- edit-profile -->
                
              </div>
            </div>
          </section>
        </div>
      </div>

    </section>
  </section>






    </div>
    <div class="widget-foot">
      <!-- Footer goes here -->
    </div>
  </div>
</div>

</div>

</div>
<!-- project team & activity end -->

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('AdminHeader.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
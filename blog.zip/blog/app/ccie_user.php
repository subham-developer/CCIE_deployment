<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ccie_user extends Model
{
    //
    protected $table = 'ccie_user';
}

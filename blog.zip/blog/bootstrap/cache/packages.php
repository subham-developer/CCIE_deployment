<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'jackiedo/timezonelist' => 
  array (
    'providers' => 
    array (
      0 => 'Jackiedo\\Timezonelist\\TimezonelistServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'maddhatter/laravel-fullcalendar' => 
  array (
    'providers' => 
    array (
      0 => 'MaddHatter\\LaravelFullcalendar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Calendar' => 'MaddHatter\\LaravelFullcalendar\\Facades\\Calendar',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
);